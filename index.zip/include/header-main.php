<header class="main-header header-style-one">

            <!-- Header Upper -->
            <div class="header-upper">
                <div class="inner-container clearfix">
                    <!--Logo-->
                    <div class="logo-box">
                        <div class="logo"><a href="index.php" title="Technagers - IT Services | Bussiness Solutions"><img
                                    src="images/logo.png" id="thm-logo" alt="Technagers - IT Services | Bussiness Solutions"
                                    title="Technagers - IT Services | Bussiness Solutions"></a></div>
                    </div>
                    <div class="nav-outer clearfix">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler"><span class="icon flaticon-menu-2"></span><span
                                class="txt">Menu</span></div>

                        <!-- Main Menu -->
                        <nav class="main-menu navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">
                                    <li><a href="index.php">Home</a></li>
                                    <!-- <li><a href="about.html">About Us</a></li>
                                    <li class="dropdown"><a href="team.html">Pages</a>
                                        <ul>
                                            <li><a href="pricing.html">Our Pricing <span>new</span></a></li>
                                            <li><a href="coming-soon.html">Coming Soon <span>new</span></a></li>
                                            <li><a href="team.html">Our Team</a></li>
                                            <li><a href="testimonials.html">Testimonials</a></li>
                                            <li><a href="faqs.html">FAQs</a></li>
                                            <li><a href="not-found.html">404 Page</a></li>
                                            <li><a href="login.html">Login Page</a></li>
                                            <li><a href="register.html">Register Page</a></li>
                                            <li><a href="forgot-password.html">Forget Page</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="services.html">Services</a>
                                        <ul>
                                            <li><a href="services.html">All Services</a></li>
                                            <li><a href="web-development.html">Website Development</a></li>
                                            <li><a href="graphic-designing.html">Graphic Designing</a></li>
                                            <li><a href="digital-marketing.html">Digital Marketing</a></li>
                                            <li><a href="seo.html">SEO & Content Writting</a></li>
                                            <li><a href="app-development.html">App Development</a></li>
                                            <li><a href="ui-designing.html">UI/UX Designing</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="portfolio.html">Portfolio</a>
                                        <ul>
                                            <li><a href="portfolio.html">Portfolio</a></li>
                                            <li><a href="portfolio-single.html">Portfolio Single 01</a></li>
                                            <li><a href="portfolio-single-2.html">Portfolio Single 02</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="shop.html">Shop</a>
                                        <ul>
                                            <li><a href="shop.html">Shop Page</a></li>
                                            <li><a href="product-details.html">Product Details</a></li>
                                            <li><a href="cart.html">Cart Page</a></li>
                                            <li><a href="checkout.html">Checkout Page</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="blog-grid.html">Blog</a>
                                        <ul>
                                            <li><a href="blog.html">Blog Sidebar</a></li>
                                            <li><a href="blog-grid.html">Blog Grid View</a></li>
                                            <li><a href="blog-single.html">Blog Single</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="contact.html">Contact</a></li> -->
                                </ul>
                            </div>
                        </nav>
                    </div>

                    <div class="other-links clearfix">
                        <!-- cart btn -->
                        <!-- <div class="cart-btn">
                            <a href="cart.html" class="theme-btn cart-toggler"><span
                                    class="flaticon-shopping-cart"></span></a>
                        </div> -->
                        <!--Search Btn-->
                        <!-- <div class="search-btn">
                            <button type="button" class="theme-btn search-toggler"><span
                                    class="flaticon-loupe"></span></button>
                        </div> -->
                        <!--<div class="link-box">
                            <div class="call-us">
                                <a class="link" href="tel:6668880000">
                                    <span class="icon"></span>
                                    <span class="sub-text">Call Anytime</span>
                                    <span class="number">666 888 0000</span>
                                </a>
                            </div>
                        </div>-->
                    </div>

                </div>
            </div>
            <!--End Header Upper-->

        </header>