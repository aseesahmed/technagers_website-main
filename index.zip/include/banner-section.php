<section class="banner-section banner-one">

          <!--  <div class="left-based-text">
                <div class="base-inner">
                    <div class="hours">
                        <ul class="clearfix">
                            <li><span>mon - fri</span></li>
                            <li><span>9am - 7pm</span></li>
                        </ul>
                    </div>
                    <div class="social-links">
                        <ul class="clearfix">
                            <li><a href="#"><span>Twitter</span></a></li>
                            <li><a href="#"><span>Facebook</span></a></li>
                            <li><a href="#"><span>Youtube</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>-->
			

            <div class="banner-carousel owl-theme owl-carousel">
                <!-- Slide Item -->
                <div class="slide-item">
                    <div class="image-layer" style="background-image: url(images/main-slider/1.jpg);"></div>
                    <div class="left-top-line"></div>
                    <div class="right-bottom-curve"></div>
                    <div class="right-top-curve"></div>
                    <div class="auto-container">
                        <div class="content-box">
                            <div class="content">
                                <div class="inner">
                                    <div class="sub-title">Welcome To</div>
                                    <h1>Technagers</h1>
									<div class="sub-title">The Technology Managers | IT Services | Business Solutions</div>
                                    <div class="link-box">
                                        <a class="theme-btn btn-style-one" href="#">
                                            <i class="btn-curve"></i>
                                            <!--<span class="btn-title">Discover More</span>-->
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Slide Item -->
                <div class="slide-item">
                    <div class="image-layer" style="background-image: url(images/main-slider/2.jpg);"></div>
                    <div class="left-top-line"></div>
                    <div class="right-bottom-curve"></div>
                    <div class="right-top-curve"></div>
                    <div class="auto-container">
                        <div class="content-box">
                            <div class="content">
                                <div class="inner">
                                    <div class="sub-title">ARE YOU A GROWING BUSINESS?</div>
                                    <h1 style="font-size: 80px;">WE KNOW HOW TO<br>
                                    MANAGE IT SMARTLY</h1>
                                    <div class="link-box">
                                        <a class="theme-btn btn-style-one" href="#">
                                            <i class="btn-curve"></i>
                                            <span class="btn-title">Discover More</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>